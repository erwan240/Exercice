import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            title: Center(
              child: Text("Je suis pauvre"),
            ),
            backgroundColor: Colors.green,
          ),
          backgroundColor: Colors.purple[100],
          body: Center(
            child: Image(
              image: AssetImage("images/launcher.png"),
            ),
          )),
    ),
  );
}
